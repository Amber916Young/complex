package com.complex.datacenter;

public class Generator {



}
